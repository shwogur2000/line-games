var currentindex=0,
    slideposition;



$(".right_btn").click(function(e){
    e.preventDefault();
    currentindex++;
    if(currentindex > 3){
        currentindex = 3;
    }
    slideposition =  currentindex * (100);
    $(".slide_wrap").animate({right:slideposition+"%"},400);
});
$(".left_btn").click(function(e){
    e.preventDefault();
    --currentindex;
    if(currentindex < 0){
        currentindex = 0;
    }
    slideposition =  currentindex * (100);
    $(".slide_wrap").animate({right:slideposition+"%"},400);
});

$(".slide_btn > li").click(function(e){
    e.preventDefault();
    var index = $(this).index();
    currentindex = index;
    slideposition =  currentindex * (100);
    $(".slide_wrap").animate({right:slideposition+"%"},400);
});

$(".family_btn").click(function(e){
    e.preventDefault();
    $(".family_cont").stop().slideToggle();
    $(".family_btn").toggleClass("on");
});